CREATE VIEW schema_object_overview AS
  SELECT
    `information_schema`.`routines`.`ROUTINE_SCHEMA` AS `db`,
    `information_schema`.`routines`.`ROUTINE_TYPE`   AS `object_type`,
    count(0)                                         AS `count`
  FROM `information_schema`.`routines`
  GROUP BY `information_schema`.`routines`.`ROUTINE_SCHEMA`, `information_schema`.`routines`.`ROUTINE_TYPE`
  UNION SELECT
          `information_schema`.`tables`.`TABLE_SCHEMA` AS `TABLE_SCHEMA`,
          `information_schema`.`tables`.`TABLE_TYPE`   AS `TABLE_TYPE`,
          count(0)                                     AS `COUNT(*)`
        FROM `information_schema`.`tables`
        GROUP BY `information_schema`.`tables`.`TABLE_SCHEMA`, `information_schema`.`tables`.`TABLE_TYPE`
  UNION SELECT
          `information_schema`.`statistics`.`TABLE_SCHEMA`                       AS `TABLE_SCHEMA`,
          concat('INDEX (', `information_schema`.`statistics`.`INDEX_TYPE`,
                 ')')                                                            AS `CONCAT('INDEX (', INDEX_TYPE, ')')`,
          count(0)                                                               AS `COUNT(*)`
        FROM `information_schema`.`statistics`
        GROUP BY `information_schema`.`statistics`.`TABLE_SCHEMA`, `information_schema`.`statistics`.`INDEX_TYPE`
  UNION SELECT
          `information_schema`.`triggers`.`TRIGGER_SCHEMA` AS `TRIGGER_SCHEMA`,
          'TRIGGER'                                        AS `TRIGGER`,
          count(0)                                         AS `COUNT(*)`
        FROM `information_schema`.`triggers`
        GROUP BY `information_schema`.`triggers`.`TRIGGER_SCHEMA`
  UNION SELECT
          `information_schema`.`events`.`EVENT_SCHEMA` AS `EVENT_SCHEMA`,
          'EVENT'                                      AS `EVENT`,
          count(0)                                     AS `COUNT(*)`
        FROM `information_schema`.`events`
        GROUP BY `information_schema`.`events`.`EVENT_SCHEMA`
  ORDER BY `db`, `object_type`;
